function result = newton(f,x0,options)
  arguments
    f function_handle
    x0 (1,1) {mustBeNumeric}
    options.eps (1,1) {mustBePositive} = 1e-6 
    options.max_steps (1,1) {mustBePositive} = 10
  end
  syms x
  df(x) = diff(f(x),x);
  x1=x0;
  steps=0;
  
  dx=double(1); % this will be a step, just initialized to 1 to get the while loop started
  while abs(dx)>options.eps && steps < options.max_steps
    dx=double(f(x1)/df(x1));
    x1 = x1-dx;
    steps = steps + 1;
    if steps == options.max_steps
        warning("The maximum number of steps have been reached.");
    end
  end
  result = x1;
end