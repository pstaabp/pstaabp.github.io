function output = simpson(f,a,b,options)
    arguments
        f function_handle
        a (1,1) {mustBeNumeric}
        b (1,1) {mustBeNumeric}
        options.n (1,1) {mustBePositive,mustBeInteger} = 10
        options.output {mustBeMember(options.output,["value","plot"])} = "plot"
    end
  dx = (b-a)/options.n;
  m = options.n/2;
  xvals = linspace(a,b,options.n+1);
  fvals = arrayfun(@(x) f(x),xvals);
  if strcmp(options.output,'plot')
    fplot(f,[a b])
    syms x a b c
    Q(x) = a*x^2+b*x+c;
    hold on
    scatter(xvals,fvals,50,'red','filled')
    for k=0:m-1
      s=solve([Q(xvals(2*k+1))==f(xvals(2*k+1)),Q(xvals(2*k+2))==f(xvals(2*k+2)),Q(xvals(2*k+3))==f(xvals(2*k+3))]);
      fplot(subs(Q(x),[a b c],[s.a s.b s.c]),[xvals(2*k+1) xvals(2*k+3)],'green')
    end
    hold off
  else
    output = dx/3*(fvals(1)+4*sum(fvals(2:2:options.n))+2*sum(fvals(3:2:options.n-1))+fvals(options.n+1));  
  end
end
