function result = bisect(f,a,b, options)
% BISECT  Finds the root of the function on the interval [a,b] using the
% bisection method.

% root = bisect(f,a,b) 
%
% Example: bisect(@(x) x^2-2,0,2) finds the root of x^2-2 on the interval
% [0,2] which returns an approximation to the square root of 2. 
%
% Optional Arguments:
%   eps: a positive real number.  This is the stopping condition.  Defaults
%   to 1e-4

  arguments
    f function_handle
    a (1,1) {mustBeReal}
    b (1,1) {mustBeReal}
    options.eps (1,1) {mustBePositive} = 1e-4 
  end
  if f(a)*f(b)>0
    error("A root is not guaranteed on the give interval.")
  end
  c = 0.5*(a+b); % calculate the midpoint of [a,b]

  if b-a< options.eps
      result = c;
  elseif (f(c)*f(a)<0)
    result = bisect(f,a,c,'eps',options.eps);
  else
    result = bisect(f,c,b,'eps',options.eps);
  end
end