function output = trapezoid(f,a,b,options)
    arguments
        f function_handle
        a (1,1) {mustBeNumeric}
        b (1,1) {mustBeNumeric}
        options.n (1,1) {mustBePositive,mustBeInteger} = 10
        options.output {mustBeMember(options.output,["value","plot"])} = "plot"
    end
  dx = (b-a)/options.n;
  xvals = linspace(a,b,options.n+1);
  fvals = arrayfun(@(x) f(x),xvals);
  if strcmp(options.output,'plot')
    fplot(f,[a b])
    hold on
    plot(xvals,fvals,'red')
    for i=1:length(xvals)
      plot([xvals(i) xvals(i)],[0 fvals(i)],'red')
    end
    hold off
  else
    output = 0.5*dx*(sum(fvals(1:options.n))+sum(fvals(2:options.n+1)));  
  end
end