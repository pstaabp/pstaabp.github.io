function result = tangentCircle(f,a)
  arguments
    f function_handle
    a (1,1) {mustBeReal}
  end
  syms x y
  df(x) = diff(f(x),x);
  d2f(x) = diff(f(x),x,2);
  
  kappa(x) = abs(d2f(x))/nthroot((1+df(x)^2)^3,2);
  if df(a)==0
      perpLine = x==a;
  else
      perpLine = y==-1/df(a)*(x-a)+f(a);
  end
  S = solve([perpLine,(x-a)^2+(y-f(a))^2==1/(kappa(a)^2)]);
  
  if d2f(a)*(f(a)-S.y(1))<0
    result = (x-S.x(1))^2 + (y-S.y(1))^2 == (1/kappa(a)^2);
  else
    result = (x-S.x(2))^2 + (y-S.y(2))^2 == (1/kappa(a)^2);
  end
  
end