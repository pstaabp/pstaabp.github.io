function output = VolumeOfRevolution(f,a,b,options)
    arguments
        f function_handle
        a (1,1) {mustBeNumeric}
        b (1,1) {mustBeNumeric}
        options.inner = ''
        options.axis {mustBeMember(options.axis,["horizontal","vertical"])} = "horizontal"
%         options.n (1,1) {mustBePositive,mustBeInteger} = 10
%         options.style {mustBeMember(options.style,["left","midpoint","right"])} = "midpoint"
%         options.output {mustBeMember(options.output,["value","plot"])} = "plot"
    end
    if strcmp(options.axis,'horizontal')
        fx = @(x,th) x;
        fy = @(x,th) f(x).*sin(th);
        fz = @(x,th) f(x).*cos(th);
        fsurf(fx,fy,fz,[a b 0 2*pi])
        colormap summer

        if isa(options.inner,'function_handle')
            gx = @(x,th) x;
            gy = @(x,th) options.inner(x).*sin(th);
            gz = @(x,th) options.inner(x).*cos(th);
            %freezeColors
            hold on
            fsurf(gx,gy,gz,[a b 0 2*pi])
            %colormap copper
            hold off
        end
    else
        fx = @(x,th) f(x).*sin(th);
        fy = @(x,th) x;
        fz = @(x,th) f(x).*cos(th);
        fsurf(fx,fy,fz,[a b 0 2*pi])
        colormap summer
         if isa(options.inner,'function_handle')
            gx = @(x,th) options.inner(x).*sin(th);
            gy = @(x,th) x;
            gz = @(x,th) options.inner(x).*cos(th);
            %freezeColors
            hold on
            fsurf(gx,gy,gz,[a b 0 2*pi])
            %colormap copper
            hold off
        end
    end
    xlabel("x")
    ylabel("y")
    zlabel("z")
end