function output = riemannSum(f,a,b,options)
    arguments
        f function_handle
        a (1,1) {mustBeNumeric}
        b (1,1) {mustBeNumeric}
        options.n (1,1) {mustBePositive,mustBeInteger} = 10
        options.style {mustBeMember(options.style,["left","midpoint","right"])} = "midpoint"
        options.output {mustBeMember(options.output,["value","plot"])} = "plot"
    end
  dx = (b-a)/options.n;
  if strcmp(options.style,'left')
    xval = linspace(a,b-dx,options.n);
    x = xval;
  elseif strcmp(options.style, 'right')
    xval = linspace(a+dx,b,options.n);
    x = xval-dx;
  else
    xval = linspace(a+0.5*dx,b-0.5*dx,options.n);
    x = xval-0.5*dx;
  end
  y =arrayfun(f,xval);
  
  if strcmp(options.output,'plot')
    g = bar(x,y,'histc'); % Moves labels to the left
    g.FaceColor = 'none';    % Changes the fill of bars
    g.EdgeColor = 'b';       % Changes edge color of bars
    hold on
    fplot(f,[a b]);
    hold off
  else
    output = dx*sum(y)
  end
end